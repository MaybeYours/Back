package xyz.itwill01.old;

public class HelloMessageObject {
	public String getHelloMessage() {
		return "Hello!!!";
	}
}
