package xyz.itwill05.di;

public class LoginController implements Controller {
	@Override
	public void handlRequest() {
		// TODO Auto-generated method stub
	}
}
