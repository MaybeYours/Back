package xyz.itwill02.factory;

public class MessagePrintApp {
	public static void main(String[] args) {
		MessagePrint print=new MessagePrint();
		print.messagePrint();
	}
}
