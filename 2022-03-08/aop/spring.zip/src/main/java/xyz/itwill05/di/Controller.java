package xyz.itwill05.di;

public interface Controller {
	void handlRequest();
}
