package xyz.itwill05.di;

public class ListController implements Controller {
	@Override
	public void handlRequest() {
		// TODO Auto-generated method stub
	}
}
