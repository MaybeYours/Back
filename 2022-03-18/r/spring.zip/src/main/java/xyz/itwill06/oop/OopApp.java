package xyz.itwill06.oop;

public class OopApp {
	public static void main(String[] args) {
		OopOne one=new OopOne();
		OopTwo two=new OopTwo();
		
		one.display1();
		one.display2();
		one.display3();
		
		two.display1();
		two.display2();
		two.display3();
	}
}
