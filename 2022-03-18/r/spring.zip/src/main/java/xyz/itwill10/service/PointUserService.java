package xyz.itwill10.service;

import xyz.itwill10.dto.PointUser;

public interface PointUserService {
	PointUser addPointUser(PointUser user);
}
