package xyz.itwill03.spring;

public interface MessageObject {
	String getMessage();
}
