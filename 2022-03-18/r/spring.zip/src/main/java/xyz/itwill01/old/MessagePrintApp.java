package xyz.itwill01.old;

public class MessagePrintApp {
	public static void main(String[] args) {
		MessagePrint print=new MessagePrint();
		
		//print.helloMessagePrint();
		print.hiMessagePrint();
	}
}
