package xyz.itwill01.old;

public class HiMessageObject {
	public String getHiMessage() {
		return "Hi!!!";
	}
}
