package xyz.itwill03.spring;

public class HiMessageObject implements MessageObject {
	@Override
	public String getMessage() {
		return "Hi!!!";
	}
}
