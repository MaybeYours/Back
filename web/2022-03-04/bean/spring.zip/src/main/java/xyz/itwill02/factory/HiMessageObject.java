package xyz.itwill02.factory;

public class HiMessageObject implements MessageObject {
	@Override
	public String getMessage() {
		return "Hi!!!";
	}
}
